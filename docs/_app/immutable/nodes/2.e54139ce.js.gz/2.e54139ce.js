import{P as m}from"../chunks/2.d04437f6.js";export{m as component};
